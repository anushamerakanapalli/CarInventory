package com.demo.car;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	CarDAO cardao;
	public String action;
	public static void main(String args[]) {
		
		System.out.println ("Welcome to the Mullet Joe's UsedCars");
		//Scanner in = new Scanner (System.in);
		//System.out.println ("Please enter the Operation: Add/List ");
		
		//@SuppressWarnings("resource")
		//ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		/*CarDAO cardao=context.getBean("cardao",CarDAO.class);
		//App ap=new App();
		//ap.saveCar(cardao);
		CarPOJO carpojo=new CarPOJO();
		cardao.saveCar(carpojo);*/
		
	        @SuppressWarnings("resource")
	           ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	           CarPOJO b = (CarPOJO) context.getBean("e");
	            Scanner sc=new Scanner(System.in);
	            //System.out.println("Welcome to Car Inventory" );
	            System.out.println("Please enter commands Add/List/Quit" );
	            String command=sc.next();
	            
	       switch (command) {
	     
	            case "Add":
	             System.out.println("Enter  car Manufacturer" );
	             b.setCarMake(sc.next());
	             System.out.println("Enter  Car Model" );
	             b.setModel(sc.next());	           
	             System.out.println("Enter  Car Year" );
	             b.setYear(sc.nextInt());
	             /*System.out.println("Enter  Car Price=" );
	             b.setSalesPrice(sr.nextFloat());*/
	             CarDAO dao = context.getBean("cardao", CarDAO.class);
	             dao.saveCar(b);
	             System.out.println("Added successfully");
	             System.out.println("Please enter commands Add/List/Quit ");
	             sc.next();
	             break;
	             
	            case "List":
	           	CarDAO cdao = context.getBean("cardao", CarDAO.class);
				List<CarPOJO> list = cdao.getAllCarsRowMapper();
				
				/*int ls=list.size();
				if(ls==" ") {
					
				}*/
	             /*for (CarPOJO e : list)
	                 System.out.println(e);*/
	             list.forEach(info->System.out.println(info));
	             System.out.println("No. of Elements in a List:"+list.size());
	             break;
	             
	             case "Quit":
	                     System.out.println("Good Bye");
	                     break;
	             case "Show":
	            	 
	            	 System.out.println("Sorry, but show is not a valid command. Please try again.");
	            	 break;
	            	 
	             default:
	            	 
	                   System.out.println("Please enter commands Add/List/Quit");
	                	  System.out.println("Good Bye");
	                  }   
	                 }
	             }
	         