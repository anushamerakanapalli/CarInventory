package com.demo.car;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class CarDAO {

	CarDAO cardao;
	
	@Autowired
	 JdbcTemplate jdbctemplate;
	
	public JdbcTemplate getJdbctemplate() {
		return jdbctemplate;
	}

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbctemplate = jdbctemplate;
	}

	/*public String saveCar(CarPOJO cp)
	{
	String insertCar="insert into car values((?,?))";
	 
	//int status = CarDAO.saveCar(new (1, "Suzuki"));
	jdbctemplate.update(insertCar);
	return insertCar;
	}*/
	
	public void saveCar(CarPOJO car) {
        String insertcar = "insert into carinvent values('"+car.getCarMake()+"','"+car.getModel()+"',"+car.getYear()+")";
        jdbctemplate.update(insertcar);
       // System.out.println("Added successfully");
    }
	
	public List<CarPOJO> getAllCarsRowMapper() {
        return jdbctemplate.query("select * from carinvent", new RowMapper<CarPOJO>() {
            public CarPOJO mapRow(ResultSet rs, int rownumber) throws SQLException {
            	CarPOJO e = new CarPOJO();
            	e.setCarMake(rs.getString(1));
                e.setModel(rs.getString(2));
                e.setYear(rs.getInt(3));
                //e.setSalesPrice(rs.getFloat(4));
                return e;         
            }
        });
	}}
