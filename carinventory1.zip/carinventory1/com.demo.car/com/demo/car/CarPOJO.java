package com.demo.car;

public class CarPOJO {
	
	//car's make, model, year, and sale price;
	private String carMake;
	private String model;
	private int year;
	//private float salesPrice;
	
//	/*public float getSalesPrice() {
//		return salesPrice;
//	}
//	public void setSalesPrice(float salesPrice) {
//		this.salesPrice = salesPrice;
//	}*/
	
	public String getCarMake() {
		return carMake;
	}
	public void setCarMake(String carMake) {
		this.carMake = carMake;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String toString() {
		
	        return carMake + " " + model + " " + year;
	    
	}
	
		
}